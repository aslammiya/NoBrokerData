package com.example.basiccalculator

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etNum1 = findViewById<EditText>(R.id.etNum1)
        val etNum2 = findViewById<EditText>(R.id.etNum2)
        val tvResult = findViewById<TextView>(R.id.tvResult)

        val btnAdd = findViewById<Button>(R.id.btnAdd)
        val btnSubtract = findViewById<Button>(R.id.btnSubtract)
        val btnMultiply = findViewById<Button>(R.id.btnMultiply)
        val btnDivide = findViewById<Button>(R.id.btnDivide)

        btnAdd.setOnClickListener {
            val result = getResult(etNum1, etNum2) { a, b -> a + b }
            tvResult.text = "Result: $result"
        }

        btnSubtract.setOnClickListener {
            val result = getResult(etNum1, etNum2) { a, b -> a - b }
            tvResult.text = "Result: $result"
        }

        btnMultiply.setOnClickListener {
            val result = getResult(etNum1, etNum2) { a, b -> a * b }
            tvResult.text = "Result: $result"
        }

        btnDivide.setOnClickListener {
            val num1 = etNum1.text.toString().toDoubleOrNull()
            val num2 = etNum2.text.toString().toDoubleOrNull()
            if (num1 != null && num2 != null && num2 != 0.0) {
                tvResult.text = "Result: ${num1 / num2}"
            } else {
                tvResult.text = "Result: Invalid input"
            }
        }
    }

    private fun getResult(et1: EditText, et2: EditText, op: (Double, Double) -> Double): String {
        val num1 = et1.text.toString().toDoubleOrNull()
        val num2 = et2.text.toString().toDoubleOrNull()
        return if (num1 != null && num2 != null) {
            op(num1, num2).toString()
        } else {
            "Invalid input"
        }
    }
}
